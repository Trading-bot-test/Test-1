# Trading bot
Bas itna kaafi hai
